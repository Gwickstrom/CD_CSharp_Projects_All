﻿using System.IO;
using Microsoft.AspNetCore.Hosting;
using System.Collections.Generic;

namespace HelloNancy
{
   
    public class Program
    {
        public static void Main(string[] args)
        {
            
                    
            IWebHost host = new WebHostBuilder()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseIISIntegration()
                .UseKestrel()
                .UseStartup<Startup>()
                .Build();
            host.Run();
                //  UseContentRoot tells the WebHost what folder to look for resources in
                //We tell the WebHost what kind of server to connect to with UseKestrel, Kestrel is the cross platform server we use for hosting our projects.
                //ensures startup.cs will be executed.
            //Run the WebHost to establish the connection

            List<string> CustomWrapperObject = new List<string>();
        }
    }
}
