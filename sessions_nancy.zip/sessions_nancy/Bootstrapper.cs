using Nancy;
using Nancy.Session.Persistable;
using Nancy.Bootstrapper;
using Nancy.TinyIoc;
using Nancy.Session.InMemory;
namespace HelloNancy

{
// all you generally have to do with Bootstrapper is add a NancyModule to your project. 
    


/* Good example of Module class 

    public class MyModule : NancyModule
    {
        private IMyDependency _dependency;

        public MyModule(IMyDependency dependency)
        {
            _dependency = dependency;

            Get["/"] = x =>
            {
            };

            // Register other routes
        }
    }
    
    4. Need something to implement IMmyDependency
*/
    
    
    
    public class Bootstrapper : DefaultNancyBootstrapper
    {
        /*
        The built in Bootstrapper uses TinyIoC to scan types on 
        application startup and registers them into the container to 
        automatically resolve dependencies.
        */
        protected override void ApplicationStartup(TinyIoCContainer container, IPipelines pipelines)
        {   

            // Don't call ConfigureRequestContainer from your ConfigureApplicationContainer.
            
            //1. Have to call the base ApplicationStartup
            
            /*For PersistableSessions 
            2. Get<T>() can be used to retrieve a strongly-typed item from the session. 
            If the item does not exist, this method will return null (or a default value for value types).

            3.GetOrDefault<T>() works the same way as Get<T>(),
                but you specify the value you want back if there's not a value in the session.
            */

            /*
                Both methods are passed the container instance as a parameter
                container.Register<IMyInterface, MyImplementation>().AsSingleton();
                container.Register<IMyInterfaceToo, MyOtherThing>().AsMultiInstance();
            */

            base.ApplicationStartup(container, pipelines);
            // PersistableSessions.Enable(pipelines, new InMemorySessionConfiguration());
            // Enable sessions
            PersistableSessions.Enable(pipelines, new InMemorySessionConfiguration());

            Session["HelloNancy"] = "Some stuff!";
            
        }
    }
}