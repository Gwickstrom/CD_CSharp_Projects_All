﻿using System;
//Here is an example of an asynchronous call to a webserver
//that returns the length of the page content after the call comes back.
using System.Net.Http;
using System.Threading.Tasks;


namespace ConsoleApplication
{
    public async static Task<long?> GetPageLength() {

        HttpClient client = new HttpClient();

        var httpMessage = await client.GetAsync("http://apress.com");

        //We can do things here while waiting
        // for the Http request to complete.

        return httpMessage.Content.Headers.ContentLength;
    }
        
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            string InputLine = Console.ReadLine();
        }
    }
}
