using Nancy;
using System.Collections.Generic;
using System;
namespace HelloNancy
{
    public class WrapperClass
    {
        public List<string> DisplayList { get; set; }

        
        public WrapperClass(object CustomWrapperObject)
        {
            WrapperClass MyObject = CustomWrapperObject as WrapperClass;
        }
        public void List<string> DisplayList(object CustomWrapperObject)
        {
            WrapperClass MyObject2 = CustomWrapperObject as WrapperClass;
            Console.WriteLine($"This thing is cool: {MyObject}");
        ) 
    }
    
    public class HelloModule : NancyModule
    {
        public HelloModule()
        {   
            // "/" an empty route. "args" holds any parameters that might be passed through the URL, 
            // The body after the fat arrow (=>) gets executed when the route is hit.
            //Once our project is configured to use Nancy, we just have to declare the types of their parameteres. 
            // As long as the function is only one line, it will attempt to evaluate the entire body as an expression and return it. More than 1 line, Curly braces. with return ...;

            //declare Get or Post routes, pass it the template for its route and an anonymous function as its two parameters
            
            

            Get("/", args => "Hello Nancy!");
            Get("/", args =>
            {   
                List<string> DisplayList = new List<string>();
                WrapperClass CustomWrapperObject = new WrapperClass(DisplayList);
                CustomWrapperObject.DisplayList = new List<string>();
                ViewBag.CustomWrapperObject = CustomWrapperObject;
                return View["Hello"];
            });


            Get("/", args =>
            {
                List<string> DisplayList = new List<string>();
                return View["Hello", DisplayList];
            });

            //Other code
            // Get("/", args =>
            // {
            //     ViewBag.number = 5;
            //     return View["Hello"];
            // });

            // Get("/", args =>
            // {
            //     return View["Hello"];
            // });

            Post("/formsubmitted", args =>
            {
                //string User = Request.Form.Username;
                //OR
                string User = Request.Form["Username"];
                return Response.AsRedirect("/");
            });

            //Syntax for anonymous function is simple. Declare any parameters needed by the function followed by a fat arrow.
            // and then the body.
            //Anonymous functions don't need to declare the types of their parameters. 

            //Ex. parameter => parameter
            //or
            // parameter => {
            //     return parameter;
            // }
            Post("/template", args =>
            {
                return Response.AsRedirect("/");
            });
            //"args" variable is where you can find any data that has been passed into the route through the URL.

            Get("/{name}", args => $"Hello {args.name}!");



            /* Example of Nancy YourModule.cs and foreach loops in Module.cs
             /*
                namespace Nancy.Demo.Samples.Modules
                {
                    using Data;
                    using Security;

                    public class Admin : NancyModule
                    {

                        public Admin(IContributorRepository contributorRepository, IDemoModelFactory demoModelFactory, IDemoRepository demoRepository)
                        {
                            this.RequiresAuthentication();

                            Delete["/contributor/{username}"] = parameters =>
                            {
                                contributorRepository.DeleteByUserName((string)parameters.username);
                                demoRepository.DeleteByAuthor((string)parameters.username);

                                return Response.AsRedirect("~/contributors");
                            };

                            Post["/contributors/refresh"] = parameters =>
                            {
                                var model =
                                    contributorRepository.GetAll();

                                demoRepository.DeleteAll();

                                foreach (var contributorModel in model)
                                {
                                    var demos =
                                        demoModelFactory.Retrieve(contributorModel.Username);

                                    foreach (var demoModel in demos)
                                    {
                                        demoRepository.Persist(demoModel);
                                    }
                                }

                                return Response.AsRedirect("~/contributors");
                            };
                        }
                    }
                }
            */

        }
    }
}