﻿using System;
using DbConnection;
namespace ConsoleApplication
{
    
    public class Program
    {
        public static void Read(object query)
        {

            for(int i = 0; )
        }
        public static void Main(string[] args)
        {
            Console.WriteLine("Hi");
           
            DbConnector.ExecuteQuery("SELECT * FROM users;");
            //To get code from the console. Sql code.
            string InputLine = Console.ReadLine();
            

        }
    }
}
