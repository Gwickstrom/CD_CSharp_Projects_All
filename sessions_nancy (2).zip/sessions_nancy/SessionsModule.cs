using Nancy;
using System.Collections.Generic;
using System;
namespace SessionsNancy

{
    /* NAMESPACES 
    1. FOR NAMESPACES naming them. Usually --- Company.Product.Feature -- or -- Company.Technology.Subnamespace ---
    <Company>.(<Product>|<Technology>)[.<Feature>][.<Subnamespace>]

    2. The following are examples:
    Fabrikam.Math
    Litware.Security
    

    3. ✓ DO use PascalCasing, and separate namespace components with periods (e.g., Microsoft.Office.PowerPoint).
     If your brand employs nontraditional casing, you should follow the casing defined by your brand, even if it deviates from normal namespace casing.
   
    4. ✓ CONSIDER using plural namespace names where appropriate.
    For example, use System.Collections instead of System.Collection. Brand names and acronyms are exceptions to this rule, however. For example, use System.IO instead of System.IOs.
    
    5. X DO NOT introduce generic type names such as Element, Node, Log, and Message.
    
    */
    // public class WrapperClass
    // {


    //     public WrapperClass(object CustomWrapperObject)
    //     {
    //         WrapperClass MyObject = CustomWrapperObject as WrapperClass;
    //     }
    //     public List<string> CustomWrapperObject { get; set; }

    //     public void DisplayList(object MyObject2)
    //     {
    //         WrapperClass MyObject = MyObject2 as WrapperClass;
    //         DisplayList(MyObject);
    //         if(MyObject == null)
    //         {
    //             Console.WriteLine("Nothing in the List");
    //         }
    //         else
    //         {
    //             Console.WriteLine($"This thing is cool: {MyObject}.");
    //         }
    //     }
    // }


    //A module is created by inheriting from the NancyModule class; it’s as simple as that. 
    //first part of YourModule needs to be name of html file

    // defining the behaviors of your application, in the form of routes 
    // and the actions they should perform if they are invoked.

    /*
    A module also gives you access to a whole range of useful things such as full
     information about the current request, access to the context in which the request 
     is being processed, helpers for building up specific kinds of responses
      (e.g json, xml, files, redirects and so on), rendering views and much more.
    */

    /*
    One of the small, yet neat, features of a module is the ability to define a module path. You can think of this as a root namespace for all the routes that are defined in the module. Each route will be subordinate to the path of the module. This saves you from having to repeat the common parts of the route patterns and also to nicely group your routes together based on their relationship

    */

    public class SessionModule : NancyModule
    {

        public class Login
        {
            public int UserID { get; set; }
            public string User { get; set; }
            public int Age { get; set; }
            public string UserName { get; set; }
            public List<Login> newList { get; set; }
            // public List<Login> userList = new List<Login>
            // {
            //     new Login(){ UserID=1, UserName="Greg", Age = 21},
            //     new Login(){ UserID=2, UserName="Jamie", Age = 21},
            //     new Login(){ UserID=3, UserName="Steven", Age = 25},
            // };
            // GET: User
        }
        public SessionModule()
        {
            // "/" an empty route. "args" holds any parameters that might be passed through the URL, 
            // The body after the fat arrow (=>) gets executed when the route is hit.
            //Once our project is configured to use Nancy, we just have to declare the types of their parameteres. 
            // As long as the function is only one line, it will attempt to evaluate the entire body as an expression and return it. More than 1 line, Curly braces. with return ...;

            //declare Get or Post routes, pass it the template for its route and an anonymous function as its two parameters


            /* DYNAMIC DICTIONARIES
            1. The most obvious place is in the lambda expression that forms the route action.
            Any captured values from the request will be put into a DynamicDictionary
            and passed into the action for the route.

            The captured value here is: hello

            2. With the DynamicDictionary you are able to access the values using a standard
             indexer approach or by using the name of the captured value just as a normal property. 


            /*
            public class AppNancyModule : NancyModule
            {
                public AppNancyModule()
                {
                    Get("/", _ => View["index"]);
                    Get("/{fileName}", parameters => View[parameters.fileName]);
                }
            }
            */
            // This Works (below)
            Post("/Index", args =>
            {
                int RandNum = new Random().Next(1, 101);
                int guess = Request.Form["RandNum"];
                return View["Index", RandNum];
            });
            Post("/Index", args =>
            {
                //string User = Request.Form.Username;
                //OR
                string User = Request.Form["Username"];
                return Response.AsRedirect("/");
            });
            Post("/Index", args =>
            {
                return Response.AsRedirect("/");
            });


            Get("/Index", args =>
            {
                ViewBag.Name = "Jordan";
                ViewBag.show = true;
                // Here we create a Random object, then use its Next() Method to generate a random number

                int RandNum = new Random().Next(1, 101);
                return View["Index", RandNum];
            });
            Get("/Reset", args =>
            {
                Session.DeleteAll();
                // Your Session is now empty.
                return Response.AsRedirect("/");
            });
            Get("/", args =>
            {
                ViewBag.Name = "Gregory";
                ViewBag.Show = true;
                List<Login> userList = new List<Login>(
                    new List<Login> {
                        new Login() { UserID=1, UserName="Greg", Age = 21},
                        new Login() { UserID=2, UserName="Jamie", Age = 21},
                        new Login() { UserID=3, UserName="Steven", Age = 25}
                    });
                Session["Index"] = "Gregory";
                return View["Index", userList];

                // new Login(){ User = args.name };
                // return args.name;
            });
            /*
            This is from the Nancy namespace. public sealed class NancyContext
            To use Request
                public Request Request
            {
                get
                {
                    return this.request;
                }

                set
                {
                    this.request = value;
                    this.Trace.RequestData = value;
                }
            }

            
            
            */

            //Other code
            // Get("/", args =>
            // {
            //     ViewBag.number = 5;
            //     return View["Hello"];
            // });

            //Syntax for anonymous function is simple. Declare any parameters needed by the function followed by a fat arrow.
            // and then the body.
            //Anonymous functions don't need to declare the types of their parameters. 

            //Ex. parameter => parameter
            //or
            // parameter => {
            //     return parameter;
            // }
            //"args" variable is where you can find any data that has been passed into the route through the URL.

            // Get("/{name}", args => $"Hello {args.name}!");

            /* Example of Nancy YourModule.cs and foreach loops in Module.cs
             /*
                namespace Nancy.Demo.Samples.Modules
                {
                    using Data;
                    using Security;

                    public class Admin : NancyModule
                    {

                        public Admin(IContributorRepository contributorRepository, IDemoModelFactory demoModelFactory, IDemoRepository demoRepository)
                        {
                            this.RequiresAuthentication();

                            Delete["/contributor/{username}"] = parameters =>
                            {
                                contributorRepository.DeleteByUserName((string)parameters.username);
                                demoRepository.DeleteByAuthor((string)parameters.username);

                                return Response.AsRedirect("~/contributors");
                            };

                            Post["/contributors/refresh"] = parameters =>
                            {
                                var model =
                                    contributorRepository.GetAll();

                                demoRepository.DeleteAll();

                                foreach (var contributorModel in model)
                                {
                                    var demos =
                                        demoModelFactory.Retrieve(contributorModel.Username);

                                    foreach (var demoModel in demos)
                                    {
                                        demoRepository.Persist(demoModel);
                                    }
                                }

                                return Response.AsRedirect("~/contributors");
                            };
                        }
                    }
                }
            */

        }
    }
}