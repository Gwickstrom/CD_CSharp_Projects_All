﻿using System;

namespace ConsoleApplication
{
    public class Human
    {
        public string name;
        public int strength { get; set;} 
        public int intelligence {get; set;}
        public int dexterity {get; set;}
        public int health = 100;

        public Human(string person)
        {
            name          = person;
            strength      = 3;
            intelligence  = 3;
            dexterity     = 3;
            health        = 100;

        }
        public Human(string person, int str, int intel, int dex, int hp)
        {
            name = person;
            strength = str;
            intelligence = intel;
            dexterity = dex;
            health = hp;
        }

        public void attack(object obj)
        {
            //Human object passed as parameter, use, object obj
            // boxing the enemy object as Human class
            Human enemy = obj as Human;
            if(enemy == null)
            {
                Console.WriteLine("Failed Attack");
            }  
            else
            {
                enemy.health -= strength * 5;
                Console.WriteLine($"Hit for: {enemy.health - (enemy.health - strength * 5)} damage");
            }
        }
    } //End Class Human
    
    public class Wizard : Human
    {
        public Wizard(string person) : base(person)
        {
            intelligence = 25;
            health = 50;
        }
        
        public Wizard(string person, int str, int intel, int dex, int hp) : base(person, str, intel, dex, hp)
        {
        }
        
        public void heal(object obj)
        {
            Wizard wiz1 = obj as Wizard;
            
            if(wiz1 == null)
            {
                Console.WriteLine("Heal Failed");
            }
            else
            {
                wiz1.health += 10 * wiz1.intelligence; 
                Console.WriteLine($"You were healed by: {wiz1.health - (10 * wiz1.intelligence)}" );  

            }
        }
        public void fireball(object obj)
        {
            Wizard enemy = obj as Wizard;

            if(enemy == null)
            {
                Console.WriteLine("Attack Failed");
            }
            else
            {
                Random rnd = new Random();
                rnd.Next(20,50);
                enemy.health -= rnd.Next(20,50);
                Console.WriteLine("random Number:" + rnd.Next(20,50));
                Console.WriteLine($"New enemy health {enemy.health}");
            }
        }
    }

    public class Ninja : Human
    {   
        public Ninja(string person) : base(person)
        {
            dexterity = 175;
        }
        public Ninja(string person, int str, int intel, int dex, int hp) : base(person, str, intel, dex, hp)
        { }
        
        public void steal(object obj)
        {   
            Ninja ninja1 = obj as Ninja;
            Human enemy = obj as Ninja;
            
            if(ninja1 == null && enemy == null)
            {
                Console.WriteLine("Attack Failed");
            }
            else
            {
                attack(enemy);
                ninja1.health += 10;
                Console.WriteLine($"{ninja1.name}'s new health: {ninja1.health} Damage done to {enemy.name} Enemy new health: {enemy.health}" + "\n");
            }
        }

        //TODO: get_away method
        public void get_away(object obj)
        {
            Ninja ninja1 = obj as Ninja;
        }
    }

    // class Rectangle
    // {
    //     //member variables
    //     protected double length;
    //     protected double width;
    //     public Rectangle(double l, double w)
    //     {
    //         length = l;
    //         width = w;
    //     }
        
    //     public double GetArea()
    //     {
    //         return length * width;
    //     }
        
    //     public void Display()
    //     {
    //         Console.WriteLine("Length: {0}", length);
    //         Console.WriteLine("Width: {0}", width);
    //         Console.WriteLine("Area: {0}", GetArea());
    //     }
    // }//end class Rectangle  

    // class Tabletop : Rectangle
    // {
    //     private double cost;
    //     public Tabletop(double l, double w) : base(l, w)
    //     { }
    //     public double GetCost()
    //     {
    //         double cost;
    //         cost = GetArea() * 70;
    //         return cost;
    //     }
    //     public void Display()
    //     {
    //         base.Display();
    //         Console.WriteLine("Cost: {0}", GetCost());
    //     }
    // }

    


    public class Program
    {
        public static void Main(string[] args)
        {
            Human greg = new Human("Greg");
            Human alex = new Human("Alex");
            Wizard gregory = new Wizard("Gregory");
            Wizard wiz2 = new Wizard("Wizardman");
            Ninja ninjaface = new Ninja("Ninjaface");
            Ninja ninjaguy = new Ninja("Ninj");

            //Can't steal from Wizards
            ninjaface.steal(ninjaguy);
            ninjaguy.steal(ninjaface);
            wiz2.heal(wiz2);

            Console.WriteLine(wiz2.name);
            Console.WriteLine($"Your new health is: {wiz2.health}");
            gregory.fireball(wiz2);
            // bool j = true;
            // bool thisistrue = (bool)j;
            greg.attack(alex);
            greg.attack("person");
            Console.WriteLine(greg.strength);
            Console.WriteLine(alex.health);

            //Optional TODO, Change last function Attack to accept any object
            // object name = greg;
            // object j = true;
            // name = (Human)greg;
            // j = (bool)true;

            // greg.Attack2(name,j);
            // greg.Attack2(alex, thisistrue);
            
            // Notice the type for the new object reference
            // is the same as the class. name
            // Declared myVehicle to be an instance or object of the class Vehicle. We also added an attribute of numPassengers to the class, that becomes part of the object variable when it is created.
            // If we wanted to pass a variable to this object when creating it to change some of its attributes, such as the numPassengers variable, we need to include a funciton inside the class called constructor.
            // A constructor is called the moment an object is created using the "new" keyword and just requires adding a function with the same name as the Class.
            
            //Adding a value to the creation passes it to the constructor
            // Vehicle myVehicle = new Vehicle(7);
            // Console.WriteLine($"My vehicle can hold {myVehicle.numPassengers} people");

            // //We create two separate objects of class-Vehicle
            // Vehicle car = new Vehicle(5);
            // Vehicle bike = new Vehicle(1);

            //Notice they both have the same starting distance travelled
            // Console.WriteLine(car.distance); //Prints 0
            // Console.WriteLine(bike.distance); //Also Prints 0

            // //The Move method however only effects the distance of the object it is referencing!!
            // car.Move(70.8);
            // Console.WriteLine(car.distance); //Now is printing 70.8
            // Console.WriteLine(bike.distance); //Still prints 0
            
            
            
            //Creating an object
            object a;
            a = 1;   // an example of boxing
            Console.WriteLine("a: " + a);
            Console.WriteLine("a.GetType(): " + a.GetType());
            Console.WriteLine("a.ToString(): " + a.ToString());

            a = new ObjectTest();
            ObjectTest classRef;
            classRef = (ObjectTest)a; 
            Console.WriteLine("classRef a: " + classRef.i); //prints out 10 from ObjectTest i = 10
        }
    }
    public class ObjectTest
    {
        public int i = 10;
    }

    public class MainClass2
    {
        static void Main2()
        {
            //Creating an object
            object a;
            a = 1;   // an example of boxing
            Console.WriteLine(a);
            Console.WriteLine(a.GetType());
            Console.WriteLine(a.ToString());

            a = new ObjectTest();
            ObjectTest classRef;
            classRef = (ObjectTest)a;
            Console.WriteLine(classRef.i);
        }
    }
}
