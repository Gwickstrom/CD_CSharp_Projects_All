using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System;

namespace AspNetSessionsController
{
    public class StringController : Controller
    {
        //Run a Test on ListOfStrings

        public class ListOfStrings
        {
            public int UserID { get; set; }
            public string User { get; set; }
            public int Age { get; set; }
            public string UserName { get; set; }
            public List<Login> newList { get; set; }
            public string DisplayList { get; set; }
            public List<ListOfStrings> DisplayAllStrings= new List<ListOfStrings>();
            public string DisplayString { get; set; }
            public List<ListOfStrings> DisplayList { get; set; }
                public List<ListOfStrings> DisplayList = new List<ListOfStrings>{
                    new ListOfStrings(){DisplayString = HttpContext.Request.Form["DisplayString 1"]},
                    new ListOfStrings(){DisplayString = HttpContext.Request.Form["DisplayString 2"]},
                    new ListOfStrings(){DisplayString = HttpContext.Request.Form["DisplayString 3"]},
                string displayList = HttpContext.Request.Form["displayList"]};
        }   
        [HttpGet]
        [Route("Views/Index")]
        public IActionResult Index()
        {
            return View("Index");
        }
              
        }
    }  
}