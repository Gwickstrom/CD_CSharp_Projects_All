using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System;
namespace AspNetSessionsController
{ 
    public class HelloWorldController : Controller
    {
        [HttpGet]
        [Route("Views/index")]
        public IActionResult Index()
        {
        return Response.WriteAsync("Hello World!");
        }
        [HttpPost]
        [Route("Views/Index")]
        public IActionResult Other()
        {
            // return View();
            //OR
            return View("Index");
            //Both of these returns will render the same view (You only need one!)
        }
        [HttpGet]
        [Route("Views/Index")]
        public IActionResult Method(string Name)
        {
        TempData["Variable"] = "Hello World";
        return RedirectToAction("OtherMethod");
        }
        public IActionResult OtherMethod()
        {
        Console.WriteLine(TempData["Variable"]);
        // Hello World
        }
        [HttpGet("api/helloworld")]
        public object HelloWorld()
        {
            return new
            {
                message = "Hello World",
                time = DateTime.Now
            };
        }

        [HttpGet("helloworld")]
        public IActionResult HelloworldMvc()
        {
            ViewBag.Message = "Hello world!";
            ViewBag.Time = DateTime.Now;

            return View("helloworld");
            //return View("~/helloworld.cshtml");
        }
    }
}