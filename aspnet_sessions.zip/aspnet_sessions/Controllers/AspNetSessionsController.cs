using System.Threading.Tasks;
using System.Collections.Generic;
using System;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace AspNetSessionsController.Controller
{

    public class AspNetSessionsController : Controller
    {

        [Route("AspNetSessions")]
        public IActionResult AspNetSessions()
        {
            // return View();
            //OR
            return Views("AspNetSessions");
        }
        [Route("Index")]
        public IActionResult GetTextField()
        {
            string TextField = Request.Form["TextField"];
            string DisplayString = Request.Form["DisplayString"];

            // List<ListOfStrings> = new List<ListOfStrings>();
            ViewBag.Info = TextField;
            return Views("Index");

        }


        
        public IActionResult Method()
        {
            HttpContext.Session.SetString("Key", "Value");
            string LocalVariable = HttpContext.Session.GetString("Key");
            HttpContext.Session.SetInt32("OtherKey", 123);
            int? IntVariable = HttpContext.Session.GetInt32("OtherKey");
            // To Clear the Session
            HttpContext.Session.Clear();
        }
        public IActionResult Method()
        {
        TempData["Variable"] = "Hello World";
        return RedirectToAction("OtherMethod");
        }
        public IActionResult OtherMethod()
        {
        Console.WriteLine(TempData["Variable"]);
        // Hello World
        }
        


        public static class SessionExtensions
        {
            public static void SetObjectAsJson(this ISession session, string key, object value)
            {
                session.SetString(key, JsonConvert.SerializeObject(value));
                List<string> NewList = new List<string>();
                HttpContext.SetObjectAsJson("TheList", NewList);
                List<string> Retrieve = HttpContext.GetObjectFromJson<List<string>>("TheList");
            }
            public static T GetObjectFromJson<T>(this ISession session, string key)
            {
                var value = session.GetString(key);
                return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
            }
        }
    }
    // public IActionResult CacheGetOrCreate()
    // {
    //     var cacheEntry = _cache.GetOrCreate(CacheKeys.Entry, entry =>
    //     {
    //         entry.SlidingExpiration = TimeSpan.FromSeconds(3);
    //         return DateTime.Now;
    //     });

    //     return View("Cache", cacheEntry);
    // }
    // public IActionResult CacheGet()
    // {
    //     var cacheEntry = _cache.Get<DateTime?>(CacheKeys.Entry);
    //     return View("Cache", cacheEntry);
    // }
    // public async Task<IActionResult> CacheGetOrCreateAsync()
    // {
    //     var cacheEntry = await
    //         _cache.GetOrCreateAsync(CacheKeys.Entry, entry =>
    //     {
    //         entry.SlidingExpiration = TimeSpan.FromSeconds(3);
    //         return Task.FromResult(DateTime.Now);
    //     });

    //     return View("Cache", cacheEntry);
    // }
    // [HttpGet]
    // public IActionResult SetPassword()
    // {
    //     return View();
    // }

    // [HttpGet]


    // [HttpGet]
    // [RouteAttribute("Time")]
    // public Task Time()
    // {
    //     return Response.WriteAsync("CurrentTime");
    // }


    // In most situations ViewBag and ViewData are interchangeable. 
    // ViewData stores our data as a generic object and must be cast on the front-end. 
    // ViewBag stores objects dynamically, 
    //which makes retrieving values easier but sacrifices the benefits of C#'s static typing.


    // With that, we can use those parameters in our method. It is key that the 
    // variable names we use here match the names on the input fields on the front end.
    // [HttpGet]
    // [Route("index")]
    // public IActionResult Index()
    // {

    // }
    // // 2. all POST routes must have an [HttpPost] before them.
    // // A POST method
    // // 3. A route of Route("template") matches the URL localhost:5000/template.
    // // They do NOT have leading slashes.
    // [HttpPost]
    // [Route("")]
    // public IActionResult AspNetSessions()
    // {

    // }
    // // We can also accept parameters in our routes:
    // [HttpGet]
    // [Route("template/{Name}")]
    // public IActionResult Method(string Name)
    // {

    // }
    //Be aware that if your method expects to receive a parameter through the URL, 
    //it will break if it doesn't receive one.

}
