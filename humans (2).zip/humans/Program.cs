﻿using System;

namespace ConsoleApplication
{
    
    public class Vehicle
    {   
        // We also added an attribute of numPassengers to the class, that becomes part of the object variable when it is created.
        public int numPassengers;
        public double distance = 0.0;
        //Accessibility of variables is defaulted to private
        //so we must add the public keyword to anything we
        //want to allow outside access to.
        

        //If we wanted to pass a variable to this object when creating it to change some 
        //of its attributes, such as the numPassengers variable, we need to include a function inside the class called a constructor
        
        //A constructor is called the moment an object is created using the new keyword 
        //and just requires adding a function with the same name as the Class.
        
        //Notice the Constructor function doesn't need
        //a return type or the static keyword
        public Vehicle(int val, double odo)
        {
            numPassengers = val;
        }

        //If a boolean is included in this version of the method call
        //it may be measuring in km rather than miles.
        // public int Move(double miles, bool km)
        // {
        //     //Convert the KM measurement to miles
        //     if (km == true)
        //     {
        //         miles = miles * 0.62;
        //     }
        //     distance += miles;
        //     // Here is the DRY principle call to the other Move function
        //     return Move(miles);
        // }
        
        // Using the .NET built-in property Getter and Setter Methods. Easily add code for access and updating of variable fields while also obscuring the methods of doing so from the rest of our code. 
        // private _numPassengers = 5;
        // public int numPassengers {
        //     get { return _numPassengers }
        //     set { _numPassengers = value;}
        // }
        
        // To implement as pure accessors (perhaps as future placeholders) with no current additional lines, they can be shortened even further
        public int numPassenger { get; set; }
        // This is the most typical usage, as it standardizes implementation and allows for the easy extension as needed
   
    }
    public class Human
    {
        public string name;
        public int strength { get; set;} 
        public int intelligence {get; set;}
        public int dexterity {get; set;}
        public int health = 100;

        public Human(string person)
        {
            name = person;
            strength = 3;
            intelligence = 3;
            dexterity = 3;
            health = 100;

        }
        public Human(string person, int str, int intel, int dex, int hp)
        {
            name = person;
            strength = str;
            intelligence = intel;
            dexterity = dex;
            health = hp;
        }

        


        public void attack(object obj)
        {
            //Human object passed as parameter, use, object obj
            // boxing the enemy object as Human class
            Human enemy = obj as Human;
            if(enemy == null)
            {
                Console.WriteLine("Failed Attack");
            }  
            else
            {
                enemy.health -= strength * 5;
                Console.WriteLine($"Hit for: {enemy.health - (enemy.health - strength * 5)} damage");
            }
        }


        //Optional Todo, Change the Last function (Attack) to accept any object and just make sure it is of type Human before applying damage.
        // public object Attack2(object name, object j)
        // {
        //     if((bool)j == true)
        //     {
        //         if(name.GetType == Human)
        //         {
        //             name.health = health - strength;
        //         }
        //          = health - (strength * 5);
        //         return name.health;
        //     }
        // }
    }
    public class Program
    {
        public static void Main(string[] args)
        {
            Human greg = new Human("Greg");
            Human alex = new Human("Alex");

            // bool j = true;
            // bool thisistrue = (bool)j;
            greg.attack(alex);
            greg.attack("person");
            Console.WriteLine(greg.strength);
            Console.WriteLine(alex.health);

            //Optional TODO, Change last function Attack to accept any object
            // object name = greg;
            // object j = true;
            // name = (Human)greg;
            // j = (bool)true;

            // greg.Attack2(name,j);
            // greg.Attack2(alex, thisistrue);
            
            // Notice the type for the new object reference
            // is the same as the class. name
            // Declared myVehicle to be an instance or object of the class Vehicle. We also added an attribute of numPassengers to the class, that becomes part of the object variable when it is created.
            // If we wanted to pass a variable to this object when creating it to change some of its attributes, such as the numPassengers variable, we need to include a funciton inside the class called constructor.
            // A constructor is called the moment an object is created using the "new" keyword and just requires adding a function with the same name as the Class.
            
            //Adding a value to the creation passes it to the constructor
            // Vehicle myVehicle = new Vehicle(7);
            // Console.WriteLine($"My vehicle can hold {myVehicle.numPassengers} people");

            // //We create two separate objects of class-Vehicle
            // Vehicle car = new Vehicle(5);
            // Vehicle bike = new Vehicle(1);

            //Notice they both have the same starting distance travelled
            // Console.WriteLine(car.distance); //Prints 0
            // Console.WriteLine(bike.distance); //Also Prints 0

            // //The Move method however only effects the distance of the object it is referencing!!
            // car.Move(70.8);
            // Console.WriteLine(car.distance); //Now is printing 70.8
            // Console.WriteLine(bike.distance); //Still prints 0
            
            
            
            //Creating an object
            object a;
            a = 1;   // an example of boxing
            Console.WriteLine("a: " + a);
            Console.WriteLine("a.GetType(): " + a.GetType());
            Console.WriteLine("a.ToString(): " + a.ToString());

            a = new ObjectTest();
            ObjectTest classRef;
            classRef = (ObjectTest)a; 
            Console.WriteLine("classRef a: " + classRef.i); //prints out 10 from ObjectTest i = 10
        }
    }
    public class ObjectTest
    {
        public int i = 10;
    }

    public class MainClass2
    {
        static void Main2()
        {
            //Creating an object
            object a;
            a = 1;   // an example of boxing
            Console.WriteLine(a);
            Console.WriteLine(a.GetType());
            Console.WriteLine(a.ToString());

            a = new ObjectTest();
            ObjectTest classRef;
            classRef = (ObjectTest)a;
            Console.WriteLine(classRef.i);
        }
    }
}
