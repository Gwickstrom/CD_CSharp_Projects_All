using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
namespace dojodachi.Controllers
{
    public class HomeController : Controller
    {

        public static class SessionExtensions
        {
            public static void SetObjectAsJson(this ISession session, string key, object value)
            {
                session.SetString(key, JsonConvert.SerializeObject(value));
            }
            public static T GetObjectFromJson<T>(this ISession session, string key)
            {
                var value = session.GetString(key);
                return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
            }
        }
        //Other code
        List<string> NewList = new List<string>();
        HttpContext.SetObjectAsJson("TheList", NewList);
        List<string> Retrieve = HttpContext.GetObjectFromJson<List<string>>("TheList");
        public static T GetValue<T>(this HttpSessionState session, string key, Func<object, T> valueSelector)
        {
            return valueSelector(session[key]);
        }
        

        public static string GetStringValue(this HttpSessionState session, string key)
        {
            return session.GetValue(key, x => (x ?? String.Empty).ToString());
        }
        public string happiness = "happiness";
        public string fullness = "fullness";
        public int energy = new int();

        HttpContext.Session.SetString("Key", "Value");
        string LocalVariable = HttpContext.Session.GetString("Key");

        HttpContext.Session.SetInt32("OtherKey", 123);
        int? IntVariable = HttpContext.Session.GetInt32("OtherKey");
        HttpContext.Session.Clear();
        // GET: /Home/
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            return View();

        }
        [HttpPost]
        [Route("method")]
        public IActionResult Method(string TextField, int NumberField)
        {
            //Code Here
        }
        public IActionResult Index()
        {
            return RedirectToAction("Index", new { parameter = "Dojodachi reacted" });
        }
        [HttpGet]
        [Route("other/{parameter}")]
        public IActionResult OtherMethod(string parameter)
        {

        }
        public IActionResult Method()
        {
            return RedirectToAction("OtherMethod", "OtherController", new { parameter = "Dojodachi reacted" });
        }
        [HttpGet]
        public Task Index()
        {
            return Response.WriteAsync("Hello");
        }
        [HttpGet]
        [Route("template/{Name}")]
        public IActionResult Method(string Name)
        {

        }
        // A POST method
        [HttpPost]
        [Route("")]
        public IActionResult Other()
        {
        }
    }
}
