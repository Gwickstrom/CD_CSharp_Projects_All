using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Configuration;
namespace aspnetcoresession.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            int? Number = HttpContext.Session.GetInt32("Number");
            if(Number == null)
            {
                Number = 0;
            }
            Number += 1;
            string PossibleCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            string PassCode = "";
            Random Rand = new Random();
            for(int i = 0; i < 14; i++)
            {
                PassCode = PassCode + PossibleCharacters[Rand.Next(0, PossibleCharacters.Length)];
            }
            ViewBag.PassCode = PassCode;
            ViewBag.RunNumber = Number;
            HttpContext.Session.SetInt32("Number", (int)Number);
            return View();
        }
    }
}
