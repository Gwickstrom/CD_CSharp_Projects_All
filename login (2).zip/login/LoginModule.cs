using Nancy;
using System.Collections.Generic;
namespace LoginNancy
{
    public class LoginModule : NancyModule
    {
        public LoginModule()
        {
            Get("/", args => "Hello");
            // This Works (below)
            Get("/login", args =>
            {
                ViewBag.Name = "Greg";
                ViewBag.Show = true;
                List<Login> userList = new List<Login>(
                    new List<Login> {
                        new Login() { UserID=1, UserName="Greg", Age = 21},
                        new Login() { UserID=2, UserName="Jamie", Age = 21},
                        new Login() { UserID=3, UserName="Steven", Age = 25}
                    });
                return View["Login", userList];
                
                // new Login(){ User = args.name };
                // return args.name;
            });
            
            // Post("/formsubmitted", args =>
            // {
            //     string User = Request.Form.Username;
            //     //OR
            //     //string User = Request.Form["Username"];
            //     return Response.AsRedirect("/");
            // });

            //This works (below)
            Get("/{name}", args =>
            {
                new Login() { User = args.name };
                return args.name;
            });

            // Get("/login", args  => 
            // {
            //     // Called when the user visits the login page or is redirected here because
            //     // an attempt was made to access a restricted resource. It should return
            //     // the view that contains the login form
            //     return "Stuff" + userList;
            // });
            Get("/logout", args =>
            {
                // Called when the user clicks the sign out button in the application. Should

                // perform one of the Logout actions (see below)
                return "logout";
            });
        }
    }
   
    public class Login
    {
        public int UserID { get; set; }
        public string User { get; set; }
        public int Age { get; set; }
        public string UserName { get; set; }
        public List<Login> newList {get; set; } 
        // public List<Login> userList = new List<Login>
        // {
        //     new Login(){ UserID=1, UserName="Greg", Age = 21},
        //     new Login(){ UserID=2, UserName="Jamie", Age = 21},
        //     new Login(){ UserID=3, UserName="Steven", Age = 25},
        // };
            // GET: User
    }
}
