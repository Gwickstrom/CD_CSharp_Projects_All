using Nancy;
using Nancy.Session.Persistable;
using Nancy.Bootstrapper;
using Nancy.TinyIoc;
using Nancy.Session.InMemory;

namespace LoginNancy
{
    public class Bootstrapper : DefaultNancyBootstrapper
    {
        /*
        The built in Bootstrapper uses TinyIoC to scan types on 
        application startup and registers them into the container to 
        automatically resolve dependencies.
        */
        protected override void ApplicationStartup(TinyIoCContainer container, IPipelines pipelines)
        {   
            base.ApplicationStartup(container, pipelines);
            // PersistableSessions.Enable(pipelines, new InMemorySessionConfiguration());
            // Enable sessions
            PersistableSessions.Enable(pipelines, new InMemorySessionConfiguration());

            // Session["HelloNancy"] = "Some stuff!";
            
        }
    }
}