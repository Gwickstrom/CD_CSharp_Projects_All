using Microsoft.AspNetCore.Builder;
using Nancy.Owin;
using Microsoft.Extensions.Logging;
namespace LoginNancy
{
    public class Startup
    {
        // LoggerFactory is for debug purposes. 
        public void Configure(IApplicationBuilder app, ILoggerFactory LoggerFactory)
        {   
            //Now, when you run a project you'll see detailed information about processes being run, 
            //and HTTP responses sent. This makes it easy to tell what response code a route gives when it's hit. 
            //Even more useful, we get verbose error messages when we have runtime errors.
            LoggerFactory.AddConsole();
            //using OWIN to connect Nancy's libraries to our project. OWIN = "Open Web Interface for .NET
            //It allows us to connect any amount of middleware to our request/response pipeline.
            // For our purposes, this means we can use it to give third party code (in this case Nancy) access to handle HTTP requests.
            app.UseOwin(x => x.UseNancy());
        }
    }
}