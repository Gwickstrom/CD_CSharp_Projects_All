﻿using System;
using System.Collections.Generic;

namespace ConsoleApplication
{
    public interface CanRun
    {
        // Anything that implements the CanRun interface must 
        // implement a 'Run()' method that returns an integer.
        int Run();
    }

    // Therefore, this class must have a Run() function in it!
    public class Goat : CanRun
    {
        public int Run()
        {
        Console.WriteLine("I'm a goat, and you betcha I can run....");
        return 5;
        }
    }

    // You can have inheritance as well as interfaces at the same time! 
    public class Bird
    {
        // Most birds don't run!!!
    }

    // An ostrich, however, is an bird AND it runs!
    // Note: always specify inheritance first, followed by interfaces (there may be multiple)
    class Ostrich: Bird, CanRun
    {
        public int Run()
        {
            Console.WriteLine("I'm a running bird...crazy, right?");
            return -16;
            // Why does an Ostrich return -16 for this function?
            // Scientists Have been working on this very problem for years.  Let's move on. 
        }
    }   
    //Extension Methods
    // Assume this is the class provided that we can not edit.
    public class Product
    {
        public List<Product> Products1 {get; set; }
        public int price;
    }
    
    public class ShoppingCart
    {
        public List<Product> Products { get; set; }
    }

    // This is the wrapper for our extension
    // Note the static keyword
    public static class MyExtensionMethods
    {
        // Note how the parameters for the new function is previous class
        public static decimal TotalPrices(this ShoppingCart cartParam)
        {
            decimal total = 0;
            foreach (Product prod in cartParam.Products)
            {
                total += prod.price;
            }
            return total;
        }
    }
    // This method is added to everything that uses the CanRun interface though!
    public static double Distance(this CanRun creature)
    {
        creature.Run();
        Console.WriteLine("I'm running a marathon now!");
        return 26.2;
    } 
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            
            // Both can now be treated as objects of type CanRun
            CanRun obj1 = new Ostrich();
            CanRun obj2 = new Goat();

        }
    }
}
